
import { GoogleGenAI, Type } from "@google/genai";
import type { Course, Resource } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        response: {
            type: Type.STRING,
            description: "A detailed, clear, and helpful explanation answering the user's query. Format it using markdown for readability (e.g., headings, bold text, lists)."
        },
        suggestions: {
            type: Type.ARRAY,
            description: "Three distinct and relevant follow-up questions the user might have after reading the response. These should encourage further learning.",
            items: {
                type: Type.STRING
            }
        },
    },
    required: ["response", "suggestions"],
};

export async function generateEducationalResponse(query: string, course: Course | null) {
    // FIX: Removed reference to non-existent 'subject' property on the 'Course' type.
    const courseContext = course 
        ? `The student is currently in the '${course.title}' course, which is a '${course.difficulty_level}' level course. Tailor your response to this context.` 
        : "The student is in a general learning context. The response should be broadly accessible.";

    const systemInstruction = `You are a friendly and knowledgeable AI tutor for ChemE Hub, a highly-esteemed educational platform specializing in Chemical Engineering. Your goal is to make learning engaging and clear.
${courseContext}
You must always provide your answer in a valid JSON format that strictly adheres to the provided schema. Do not include any text or markdown formatting outside of the JSON structure.`;
    
    const prompt = `Please provide an educational response to the following query: "${query}"`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema,
                temperature: 0.7,
                topP: 0.95,
            },
        });
        
        const jsonText = response.text.trim();
        const parsedResponse = JSON.parse(jsonText);

        return {
            response: parsedResponse.response || "No response text found.",
            suggestions: parsedResponse.suggestions || [],
        };

    } catch (error) {
        console.error("Gemini API call failed:", error);
        throw new Error("Failed to generate response from AI.");
    }
}

export async function generateSummaryForResources(resources: Resource[]): Promise<string> {
    const resourceDetails = resources.map(r => `- "${r.title}" from ${r.source}`).join('\n');

    const systemInstruction = "You are a helpful academic assistant. Your task is to synthesize information from various sources into a single, well-structured summary for a chemical engineering student. Use markdown for formatting (e.g., headings, bold text, lists) to create a document that can serve as a study guide.";
    
    const prompt = `Please generate a comprehensive summary based on the following learning resources:\n${resourceDetails}\n\nThe summary should cover the key concepts from these topics and explain how they might relate to each other.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                systemInstruction,
                temperature: 0.5,
            },
        });
        
        return response.text;

    } catch (error) {
        console.error("Gemini API call for summary failed:", error);
        throw new Error("Failed to generate summary from AI.");
    }
}
