import type { Course } from '../types';
import { MOCK_COURSES } from '../constants';

// In-memory store, seeded with mock data
let courses: Course[] = [...MOCK_COURSES];
let nextId = courses.reduce((maxId, course) => Math.max(parseInt(course.id.split('-')[1] || '0'), maxId), 0) + 1;


// Simulate API delay
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export const getCourses = async (): Promise<Course[]> => {
    await delay(50); // Simulate network latency
    return Promise.resolve([...courses]);
};

export const addCourse = async (courseData: Omit<Course, 'id'>): Promise<Course> => {
    await delay(100);
    const newCourse: Course = {
        ...courseData,
        id: `che-${nextId++}`,
        modules: courseData.modules.map((m, i) => ({ ...m, id: `mod-${Date.now()}-${i}` })),
        assignments: courseData.assignments.map((a, i) => ({ ...a, id: `assign-${Date.now()}-${i}` })),
    };
    courses.push(newCourse);
    return Promise.resolve(newCourse);
};

export const updateCourse = async (updatedCourse: Course): Promise<Course> => {
    await delay(100);
    const courseIndex = courses.findIndex(c => c.id === updatedCourse.id);
    if (courseIndex === -1) {
        throw new Error('Course not found');
    }
    // Ensure modules have unique IDs
    const modulesWithIds = updatedCourse.modules.map((m, i) => ({
        ...m,
        id: m.id.startsWith('new-') ? `mod-${Date.now()}-${i}` : m.id,
    }));
    // Ensure assignments have unique IDs
    const assignmentsWithIds = updatedCourse.assignments.map((a, i) => ({
        ...a,
        id: a.id.startsWith('new-') ? `assign-${Date.now()}-${i}` : a.id,
    }));
    const newCourseData = { ...updatedCourse, modules: modulesWithIds, assignments: assignmentsWithIds };
    courses[courseIndex] = newCourseData;
    return Promise.resolve(newCourseData);
};

export const deleteCourse = async (courseId: string): Promise<void> => {
    await delay(100);
    courses = courses.filter(c => c.id !== courseId);
    return Promise.resolve();
};