

import React, { useState, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import type { Message, Course, Stats, NavItem, User } from './types';
import { MessageType, UserRole } from './types';
import { MOCK_STATS, WELCOME_MESSAGE, NAV_ITEMS, MOCK_USERS } from './constants';
import { generateEducationalResponse } from './services/geminiService';
import * as courseService from './services/courseService';
import { AdminView } from './components/AdminView';
import { StudentDashboard } from './components/StudentDashboard';
import { PersonalizedLearningView } from './components/PersonalizedLearningView';
import { VisualizationDemoView } from './components/VisualizationDemoView';
import { ResearchLibraryView } from './components/ResearchLibraryView';


const PlaceholderView: React.FC<{ title: string }> = ({ title }) => (
    <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-8 rounded-2xl">
        <h2 className="text-2xl font-bold text-white mb-4">{title}</h2>
        <p className="text-gray-400">This section is under construction. Please check back later for more updates.</p>
    </div>
);


export default function App() {
  const [messages, setMessages] = useState<Message[]>([WELCOME_MESSAGE]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeNav, setActiveNav] = useState<string>('Dashboard');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [currentUser, setCurrentUser] = useState<User>(MOCK_USERS.student);
  const [courses, setCourses] = useState<Course[]>([]);
  const stats: Stats = MOCK_STATS;
  const navItems: NavItem[] = NAV_ITEMS;

  React.useEffect(() => {
    courseService.getCourses().then(setCourses);
  }, []);

  const filteredNavItems = useMemo(() => navItems.filter(item => 
    !item.permissions || item.permissions.includes(currentUser.role)
  ), [currentUser.role, navItems]);

  React.useEffect(() => {
    const currentNavItem = navItems.find(item => item.name === activeNav);
    if (currentNavItem?.permissions && !currentNavItem.permissions.includes(currentUser.role)) {
      setActiveNav('Dashboard');
    }
  }, [currentUser.role, activeNav, navItems]);
  
  const handleToggleModule = useCallback((courseId: string, moduleId: string) => {
    setCurrentUser(prevUser => {
        if (prevUser.role !== UserRole.STUDENT) return prevUser;
        const newProgress = { ...prevUser.progress };
        const courseProgress = newProgress[courseId] ? [...newProgress[courseId]] : [];
        
        const moduleIndex = courseProgress.indexOf(moduleId);
        if (moduleIndex > -1) {
            courseProgress.splice(moduleIndex, 1);
        } else {
            courseProgress.push(moduleId);
        }
        
        newProgress[courseId] = courseProgress;
        
        return { ...prevUser, progress: newProgress };
    });
  }, []);

  const handleSendMessage = useCallback(async (content: string, learningLevel: string) => {
    if (!content.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: MessageType.USER,
      content: content.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const fullQuery = `${content} (explain this at a "${learningLevel}" level)`;
      const aiResponseData = await generateEducationalResponse(fullQuery, selectedCourse);
      
      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        type: MessageType.AI,
        content: aiResponseData.response,
        timestamp: new Date(),
        suggestions: aiResponseData.suggestions,
      };
      setMessages(prev => [...prev, aiMessage]);

    } catch (error) {
      console.error('Error generating AI response:', error);
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        type: MessageType.AI,
        content: "I apologize, but I'm having trouble processing your request right now. Please check your Gemini API key and try again later.",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, selectedCourse]);

  const handleAddCourse = useCallback(async (courseData: Omit<Course, 'id'>) => {
    await courseService.addCourse(courseData);
    courseService.getCourses().then(setCourses);
  }, []);

  const handleUpdateCourse = useCallback(async (course: Course) => {
    await courseService.updateCourse(course);
    courseService.getCourses().then(setCourses);
  }, []);

  const handleDeleteCourse = useCallback(async (courseId: string) => {
    if (window.confirm('Are you sure you want to delete this course?')) {
        await courseService.deleteCourse(courseId);
        courseService.getCourses().then(setCourses);
    }
  }, []);
  
  const renderContent = () => {
    switch (activeNav) {
      case 'Dashboard':
        return (
          <StudentDashboard
            currentUser={currentUser}
            courses={courses}
          />
        );
      case 'Personalized Learning':
        return (
           <PersonalizedLearningView
              messages={messages}
              isLoading={isLoading}
              onSendMessage={handleSendMessage}
            />
        );
      case 'Visualization Demo':
        return <VisualizationDemoView />;
      case 'Research Library':
        return <ResearchLibraryView />;
      case 'Admin':
        return currentUser.role === UserRole.ADMIN ? (
            <AdminView 
                courses={courses}
                onAddCourse={handleAddCourse}
                onUpdateCourse={handleUpdateCourse}
                onDeleteCourse={handleDeleteCourse}
            />
        ) : <PlaceholderView title="Access Denied" />;
      case 'Settings':
        return <PlaceholderView title="Settings" />;
      default:
        return <PlaceholderView title="Not Found" />;
    }
  };

  return (
    <div className="min-h-screen text-gray-200 font-sans flex">
      <Sidebar 
        navItems={filteredNavItems}
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        courses={courses}
        selectedCourse={selectedCourse}
        setSelectedCourse={setSelectedCourse}
        currentUser={currentUser}
        onToggleModule={handleToggleModule}
      />
      <div className="flex-1 flex flex-col">
        <Header 
            activeView={activeNav}
            selectedCourse={selectedCourse} 
            currentUser={currentUser}
            setCurrentUser={setCurrentUser}
        />
        <main className="flex-1 p-8 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}