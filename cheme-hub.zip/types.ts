

// FIX: Import React to resolve 'Cannot find namespace 'React'' error.
import React from 'react';

export enum MessageType {
  USER = 'user',
  AI = 'ai',
}

export interface Message {
  id: string;
  type: MessageType;
  content: string;
  timestamp: Date;
  sources?: string[];
  suggestions?: string[];
}

export interface Module {
  id: string;
  title: string;
}

export interface Assignment {
  id:string;
  title: string;
  type: 'in-class' | 'group' | 'individual';
  weighting: number;
}

export interface Course {
  id: string;
  title: string;
  difficulty_level: string;
  modules: Module[];
  assignments: Assignment[];
}

export interface Stats {
  users: number;
  courses: number;
  sessions: number;
}

export enum UserRole {
  STUDENT = 'student',
  INSTRUCTOR = 'instructor',
  ADMIN = 'admin',
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  progress: Record<string, string[]>; // { [courseId]: [moduleId, moduleId, ...] }
}

export interface NavItem {
  name: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  permissions?: UserRole[];
}

export interface Recommendation {
    id: string;
    title: string;
    category: string;
    status: 'Not Started' | 'In Progress' | 'Completed';
}

export type ResourceType = 'video' | 'pdf' | 'web';

export interface Resource {
    id: number;
    title: string;
    source: string;
    type: ResourceType;
    url: string;
}
