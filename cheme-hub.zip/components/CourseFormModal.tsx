import React, { useState, useEffect } from 'react';
import type { Course, Module, Assignment } from '../types';
import { PlusIcon, TrashIcon } from './Icons';

interface CourseFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (course: Course | Omit<Course, 'id'>) => void;
  course: Course | null;
}

const BLANK_COURSE: Omit<Course, 'id'> = {
  title: '',
  difficulty_level: 'intermediate',
  modules: [],
  assignments: [],
};

export const CourseFormModal: React.FC<CourseFormModalProps> = ({ isOpen, onClose, onSave, course }) => {
  const [formData, setFormData] = useState<Course | Omit<Course, 'id'>>(BLANK_COURSE);
  const [newModuleTitle, setNewModuleTitle] = useState('');
  const [newAssignment, setNewAssignment] = useState<{title: string; type: Assignment['type']; weighting: number}>({
    title: '',
    type: 'individual',
    weighting: 10,
  });

  useEffect(() => {
    if (isOpen) {
        // Deep copy modules and assignments to prevent direct state mutation
        const initialModules = course?.modules.map(m => ({...m})) || [];
        const initialAssignments = course?.assignments.map(a => ({...a})) || [];
        setFormData(course ? { ...course, modules: initialModules, assignments: initialAssignments } : BLANK_COURSE);
    }
  }, [isOpen, course]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleModuleChange = (index: number, value: string) => {
    const updatedModules = [...formData.modules];
    updatedModules[index] = { ...updatedModules[index], title: value };
    setFormData({ ...formData, modules: updatedModules });
  };
  
  const handleAssignmentChange = (index: number, field: keyof Omit<Assignment, 'id'>, value: string | number) => {
    const updatedAssignments = [...formData.assignments];
    (updatedAssignments[index] as any)[field] = value;
    setFormData({ ...formData, assignments: updatedAssignments });
  };


  const handleAddModule = () => {
    if (newModuleTitle.trim()) {
      const newModule: Module = { id: `new-${Date.now()}`, title: newModuleTitle.trim() };
      setFormData({ ...formData, modules: [...formData.modules, newModule] });
      setNewModuleTitle('');
    }
  };
  
  const handleRemoveModule = (index: number) => {
    const updatedModules = formData.modules.filter((_, i) => i !== index);
    setFormData({ ...formData, modules: updatedModules });
  };
  
  const handleAddAssignment = () => {
    if (newAssignment.title.trim() && newAssignment.weighting > 0) {
        const assignmentToAdd: Assignment = {
            id: `new-${Date.now()}`,
            title: newAssignment.title.trim(),
            type: newAssignment.type,
            weighting: Number(newAssignment.weighting),
        };
        setFormData(prev => ({...prev, assignments: [...prev.assignments, assignmentToAdd]}));
        setNewAssignment({ title: '', type: 'individual', weighting: 10 });
    }
  };
  
  const handleRemoveAssignment = (index: number) => {
    const updatedAssignments = formData.assignments.filter((_, i) => i !== index);
    setFormData({ ...formData, assignments: updatedAssignments });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.title.trim()) {
        onSave(formData);
    }
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 transition-opacity duration-300 animate-fade-in" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="course-modal-title">
      <div className="bg-gray-900/80 backdrop-blur-xl border border-gray-700/50 rounded-2xl shadow-2xl w-full max-w-2xl m-4 text-white transform transition-all duration-300 animate-scale-in" onClick={e => e.stopPropagation()}>
        <form onSubmit={handleSubmit}>
          <div className="p-6 max-h-[80vh] overflow-y-auto">
            <h2 id="course-modal-title" className="text-2xl font-bold mb-4">{course ? 'Edit Course' : 'Create New Course'}</h2>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-400 mb-1">Course Title</label>
                <input type="text" name="title" id="title" value={formData.title} onChange={handleChange} required className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"/>
              </div>

              <div>
                <label htmlFor="difficulty_level" className="block text-sm font-medium text-gray-400 mb-1">Difficulty</label>
                <select name="difficulty_level" id="difficulty_level" value={formData.difficulty_level} onChange={handleChange} className="w-full p-2 bg-gray-800 border border-gray-700 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-8">
                {/* Modules Section */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">Modules</h3>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-2 mb-3">
                    {formData.modules.map((module, index) => (
                      <div key={module.id || index} className="flex items-center space-x-2">
                        <input type="text" value={module.title} onChange={(e) => handleModuleChange(index, e.target.value)} placeholder="Module title" className="flex-1 p-2 bg-gray-800 border border-gray-700 rounded-lg" />
                        <button type="button" onClick={() => handleRemoveModule(index)} className="p-2 text-gray-400 hover:text-accent-red hover:bg-red-500/10 rounded-full transition-colors" aria-label={`Remove module ${module.title}`}>
                          <TrashIcon className="h-5 w-5" />
                        </button>
                      </div>
                    ))}
                     {formData.modules.length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-4">No modules yet.</p>
                    )}
                  </div>
                   <div className="flex items-center space-x-2">
                    <input type="text" value={newModuleTitle} onChange={(e) => setNewModuleTitle(e.target.value)} placeholder="New module title" onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddModule())} className="flex-1 p-2 bg-gray-800 border border-gray-700 rounded-lg"/>
                    <button type="button" onClick={handleAddModule} className="p-2 text-gray-400 hover:text-primary-light hover:bg-primary/10 rounded-full transition-colors" aria-label="Add new module">
                        <PlusIcon className="h-6 w-6" />
                    </button>
                  </div>
                </div>
                
                {/* Assessments Section */}
                <div>
                  <h3 className="text-lg font-semibold mb-2">Assessments</h3>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-2 mb-3">
                     {formData.assignments.map((assignment, index) => (
                      <div key={assignment.id || index} className="flex items-center space-x-2 bg-gray-800/50 p-2 rounded-lg">
                        <input type="text" value={assignment.title} onChange={(e) => handleAssignmentChange(index, 'title', e.target.value)} placeholder="Assignment title" className="flex-1 p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm" />
                        <select value={assignment.type} onChange={(e) => handleAssignmentChange(index, 'type', e.target.value)} className="p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm w-24">
                            <option value="individual">Individual</option>
                            <option value="group">Group</option>
                            <option value="in-class">In-Class</option>
                        </select>
                        <input type="number" value={assignment.weighting} onChange={(e) => handleAssignmentChange(index, 'weighting', Number(e.target.value))} placeholder="%" className="w-16 p-2 bg-gray-700 border border-gray-600 rounded-lg text-sm" />
                        <button type="button" onClick={() => handleRemoveAssignment(index)} className="p-2 text-gray-400 hover:text-accent-red hover:bg-red-500/10 rounded-full transition-colors" aria-label={`Remove assignment ${assignment.title}`}>
                            <TrashIcon className="h-5 w-5" />
                        </button>
                      </div>
                    ))}
                    {formData.assignments.length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-4">No assessments yet.</p>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="text" value={newAssignment.title} onChange={(e) => setNewAssignment({...newAssignment, title: e.target.value})} placeholder="New assignment" className="flex-1 p-2 bg-gray-800 border border-gray-700 rounded-lg"/>
                    <select value={newAssignment.type} onChange={(e) => setNewAssignment({...newAssignment, type: e.target.value as Assignment['type']})} className="p-2 bg-gray-800 border border-gray-700 rounded-lg w-24">
                        <option value="individual">Individual</option>
                        <option value="group">Group</option>
                        <option value="in-class">In-Class</option>
                    </select>
                    <input type="number" value={newAssignment.weighting} onChange={(e) => setNewAssignment({...newAssignment, weighting: Number(e.target.value)})} placeholder="%" className="w-16 p-2 bg-gray-800 border border-gray-700 rounded-lg"/>
                    <button type="button" onClick={handleAddAssignment} className="p-2 text-gray-400 hover:text-primary-light hover:bg-primary/10 rounded-full transition-colors" aria-label="Add new assignment">
                        <PlusIcon className="h-6 w-6" />
                    </button>
                  </div>
                </div>
            </div>
          </div>

          <div className="bg-gray-800/50 px-6 py-4 rounded-b-2xl flex justify-end space-x-3">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors font-semibold">Save Course</button>
          </div>
        </form>
      </div>
    </div>
  );
};