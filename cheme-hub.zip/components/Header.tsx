
import React from 'react';
import type { Course, User } from '../types';
import { MOCK_USERS } from '../constants';

interface HeaderProps {
    activeView: string;
    selectedCourse: Course | null;
    currentUser: User;
    setCurrentUser: (user: User) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeView, selectedCourse, currentUser, setCurrentUser }) => {
  const getRoleStyles = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-accent-red/20 text-accent-red';
      case 'instructor': return 'bg-accent-blue/20 text-accent-blue';
      default: return 'bg-green-500/20 text-green-400';
    }
  };

  const getRoleRingColor = (role: string) => {
    switch (role) {
      case 'admin': return 'ring-accent-red/50';
      case 'instructor': return 'ring-accent-blue/50';
      default: return 'ring-green-500/50';
    }
  };

  return (
    <header className="h-20 flex items-center justify-between px-8 border-b border-gray-800/50">
        <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">{activeView}</h1>
            <p className="text-sm text-gray-400">
                {selectedCourse ? `Current Context: ${selectedCourse.title}` : "General AI Tutor"}
            </p>
        </div>
        <div className="flex items-center space-x-4">
            <div className="flex items-center bg-gray-800/80 rounded-lg p-1 space-x-1">
                {Object.values(MOCK_USERS).map(user => (
                    <button
                        key={user.id}
                        onClick={() => setCurrentUser(user)}
                        className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                            currentUser.id === user.id
                            ? 'bg-primary text-white shadow'
                            : 'text-gray-400 hover:bg-gray-700/50'
                        }`}
                    >
                        Switch to {user.role}
                    </button>
                ))}
            </div>
             <div className="flex items-center space-x-3">
                <div className="text-right">
                    <p className="font-semibold text-white text-sm">{currentUser.name}</p>
                    <p className={`text-xs px-2 py-0.5 rounded-full inline-block font-medium capitalize ${getRoleStyles(currentUser.role)}`}>
                        {currentUser.role}
                    </p>
                </div>
                <div className={`w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center text-white font-bold ring-2 ring-offset-2 ring-offset-gray-900 ${getRoleRingColor(currentUser.role)}`}>
                    {currentUser.name.charAt(0)}
                </div>
            </div>
        </div>
    </header>
  );
};