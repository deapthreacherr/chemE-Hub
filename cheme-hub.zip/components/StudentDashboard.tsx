import React, { useMemo } from 'react';
import type { Course, User, Recommendation } from '../types';
import { RECOMMENDATIONS_DATA } from '../constants';
import { CheckCircleIcon } from './Icons';

const Recommendations: React.FC<{ recommendations: Recommendation[] }> = ({ recommendations }) => (
  <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-6 rounded-2xl col-span-1 lg:col-span-2">
    <h3 className="font-bold text-white text-lg mb-4">Recommended For You</h3>
    <div className="space-y-4">
      {recommendations.map(rec => (
        <div key={rec.id} className="bg-gray-700/50 p-4 rounded-lg flex items-center justify-between hover:bg-gray-700 transition-colors">
          <div>
            <p className="font-semibold text-white">{rec.title}</p>
            <p className="text-sm text-gray-400">{rec.category}</p>
          </div>
          <div className={`text-xs px-2 py-1 rounded-full flex items-center space-x-1 ${
            rec.status === 'Completed' ? 'bg-green-500/20 text-green-400' :
            rec.status === 'In Progress' ? 'bg-yellow-500/20 text-yellow-400' :
            'bg-gray-600 text-gray-300'
          }`}>
             {rec.status === 'Completed' && <CheckCircleIcon className="h-3 w-3" />}
            <span>{rec.status}</span>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const ProgressChart: React.FC<{ currentUser: User; courses: Course[] }> = ({ currentUser, courses }) => {
    const userProgress = useMemo(() => {
        if (!currentUser.progress) return [];
        
        return courses
            .map(course => {
                const completedModulesCount = currentUser.progress[course.id]?.length || 0;
                const totalModules = course.modules.length;
                const percentage = totalModules > 0 ? Math.round((completedModulesCount / totalModules) * 100) : 0;

                return {
                    id: course.id,
                    title: course.title,
                    percentage,
                };
            })
            .filter(Boolean) as { id: string; title: string; percentage: number }[];
    }, [currentUser.progress, courses]);

    if (currentUser.role !== 'student' || userProgress.length === 0) {
        return (
             <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-6 rounded-2xl col-span-1 lg:col-span-1">
                <h3 className="font-bold text-white text-lg mb-4">Skill Meter</h3>
                <div className="flex items-center justify-center h-full">
                   <p className="text-gray-400 text-sm">Start a course to see your progress.</p>
                </div>
            </div>
        );
    }
    
    return (
        <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-6 rounded-2xl col-span-1 lg:col-span-1">
            <h3 className="font-bold text-white text-lg mb-4">Skill Meter</h3>
            <div className="space-y-4">
                {userProgress.map(progress => (
                    <div key={progress.id}>
                        <div className="flex justify-between mb-1 text-sm font-medium text-gray-300">
                            <span>{progress.title}</span>
                            <span>{progress.percentage}%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2.5">
                            <div className="bg-gradient-to-r from-primary-light to-primary h-2.5 rounded-full" style={{ width: `${progress.percentage}%` }}></div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export const StudentDashboard: React.FC<{ currentUser: User; courses: Course[] }> = ({ currentUser, courses }) => {
  const recommendations = RECOMMENDATIONS_DATA;
  
  return (
    <div className="space-y-8">
       <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
         <Recommendations recommendations={recommendations} />
         <ProgressChart currentUser={currentUser} courses={courses} />
      </div>
       <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-8 rounded-2xl">
        <h2 className="text-2xl font-bold text-white mb-4">Welcome back, {currentUser.name}!</h2>
        <p className="text-gray-400">Navigate to 'Personalized Learning' to chat with the AI tutor, or explore the 'Visualization Demo' and 'Research Library' to enhance your studies. Your progress is saved automatically.</p>
    </div>
    </div>
  );
};
