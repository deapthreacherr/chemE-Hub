import React, { useState } from 'react';
import type { Message } from '../types';
import { MessageType } from '../types';
import { SparklesIcon, StarIcon } from './Icons';

interface MessageBubbleProps {
  message: Message;
  onSuggestionClick: (suggestion: string) => void;
}

const Feedback: React.FC<{ messageId: string }> = ({ messageId }) => {
    const [feedbackSent, setFeedbackSent] = useState(false);
    const [hoveredScore, setHoveredScore] = useState(0);

    const submitFeedback = (score: number) => {
        console.log(`Feedback for message ${messageId}: ${score} stars`);
        setFeedbackSent(true);
    };

    if (feedbackSent) {
        return <p className="text-xs text-green-400 font-medium">Thank you for your feedback!</p>;
    }

    return (
        <div className="flex items-center space-x-3">
            <span className="text-xs text-gray-400">Rate this response:</span>
            <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((score) => (
                    <button
                        key={score}
                        onClick={() => submitFeedback(score)}
                        onMouseEnter={() => setHoveredScore(score)}
                        onMouseLeave={() => setHoveredScore(0)}
                        className="text-gray-600 hover:text-yellow-400 transition-colors"
                    >
                        <StarIcon className={`h-4 w-4 ${(hoveredScore > 0 && score <= hoveredScore) ? 'text-yellow-400' : ''}`} />
                    </button>
                ))}
            </div>
        </div>
    );
};


export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, onSuggestionClick }) => {
  const isUser = message.type === MessageType.USER;

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
       {!isUser && (
           <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-1">
               <SparklesIcon className="h-5 w-5 text-primary-light" />
           </div>
        )}
      <div className={`max-w-3xl w-fit rounded-2xl ${isUser ? 'bg-gradient-to-br from-primary-light to-primary-dark text-white rounded-br-lg' : 'bg-gray-700/70 text-gray-200 rounded-bl-lg'}`}>
        <div className="px-5 py-4">
            <div className="flex-1">
                <div className="prose prose-sm max-w-none prose-invert prose-p:text-gray-200" dangerouslySetInnerHTML={{ __html: message.content.replace(/\n/g, '<br>') }} />
                
                {!isUser && message.suggestions && message.suggestions.length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-600/50">
                    <p className="text-xs text-gray-400 font-semibold mb-2">Suggested questions:</p>
                    <div className="flex flex-wrap gap-2">
                    {message.suggestions.map((suggestion, idx) => (
                        <button
                        key={idx}
                        onClick={() => onSuggestionClick(suggestion)}
                        className="block text-xs text-primary-light bg-primary/10 hover:bg-primary/20 px-2 py-1 rounded-full transition"
                        >
                        {suggestion}
                        </button>
                    ))}
                    </div>
                </div>
                )}
                
                {!isUser && (
                <div className="mt-4 pt-4 border-t border-gray-600/50">
                   <Feedback messageId={message.id} />
                </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};
