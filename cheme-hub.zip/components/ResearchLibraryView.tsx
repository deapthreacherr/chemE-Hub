
import React, { useState } from 'react';
import { generateSummaryForResources } from '../services/geminiService';
import type { Resource, ResourceType } from '../types';
import { FileTextIcon, YoutubeIcon, GlobeIcon, CheckboxIcon, SparklesIcon } from './Icons';


const MOCK_RESOURCES: Resource[] = [
    { id: 1, title: 'PID Controllers Explained', source: 'YouTube - The Efficient Engineer', type: 'video', url: 'https://www.youtube.com/watch?v=zgaRfnA_6w8' },
    { id: 2, title: 'Fundamentals of Mass Transfer', source: 'che.utah.edu - PDF', type: 'pdf', url: '#' },
    { id: 3, title: 'Wastewater Treatment Processes', source: 'Wikipedia', type: 'web', url: 'https://en.wikipedia.org/wiki/Wastewater_treatment' },
    { id: 4, title: 'Distillation Column Design', source: 'ScienceDirect Article', type: 'web', url: '#' },
    { id: 5, title: 'Laplace Transforms for Engineers', source: 'YouTube - Khan Academy', type: 'video', url: 'https://www.youtube.com/watch?v=6-4L_dwyNid' },
    { id: 6, title: 'Perry\'s Chemical Engineers\' Handbook', source: 'Access Engineering - PDF', type: 'pdf', url: '#' },
];

const SummaryModal: React.FC<{ summary: string; onClose: () => void }> = ({ summary, onClose }) => {
    
    const handlePrint = () => {
        const printWindow = window.open('', '_blank');
        if (!printWindow) {
            alert("Please allow popups to print the summary.");
            return;
        }
        
        printWindow.document.write(`
            <html>
                <head>
                    <title>ChemE Hub - Study Summary</title>
                    <style>
                        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; line-height: 1.6; padding: 2rem; color: #111; }
                        h1, h2, h3 { font-weight: bold; margin-top: 1.5em; margin-bottom: 0.5em; }
                        ul, ol { padding-left: 1.5em; }
                        li { margin-bottom: 0.5em; }
                        p { margin-bottom: 1em; }
                        strong { font-weight: bold; }
                        code { font-family: monospace; background-color: #f4f4f4; padding: 2px 4px; border-radius: 4px; }
                    </style>
                </head>
                <body>
                    <h1>Study Summary</h1>
                    ${summary.replace(/\n/g, '<br>')}
                </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => { // Timeout needed for content to render before printing
            printWindow.print();
            printWindow.close();
        }, 500);
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in" onClick={onClose} role="dialog" aria-modal="true">
            <div className="bg-gray-900/80 backdrop-blur-xl border border-gray-700/50 rounded-2xl shadow-2xl w-full max-w-3xl m-4 text-white transform animate-scale-in" onClick={e => e.stopPropagation()}>
                <div className="p-6 border-b border-gray-700">
                    <h2 className="text-xl font-bold">Generated Summary</h2>
                </div>
                <div className="p-6 max-h-[60vh] overflow-y-auto prose prose-sm max-w-none prose-invert prose-p:text-gray-200"
                    dangerouslySetInnerHTML={{ __html: summary.replace(/\n/g, '<br>') }}
                />
                <div className="bg-gray-800/50 px-6 py-4 rounded-b-2xl flex justify-end space-x-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors">Close</button>
                    <button type="button" onClick={handlePrint} className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors font-semibold">Print / Save as PDF</button>
                </div>
            </div>
        </div>
    );
};

const ResourceCard: React.FC<{ resource: Resource; isSelected: boolean; onSelect: () => void; }> = ({ resource, isSelected, onSelect }) => {
    const typeDetails: Record<ResourceType, { icon: React.FC<any>, color: string }> = {
        video: { icon: YoutubeIcon, color: 'text-red-500' },
        pdf: { icon: FileTextIcon, color: 'text-orange-500' },
        web: { icon: GlobeIcon, color: 'text-blue-500' },
    };

    const Icon = typeDetails[resource.type].icon;
    const color = typeDetails[resource.type].color;

    return (
        <div onClick={onSelect} className={`bg-gray-800/50 backdrop-blur-md border border-gray-700/50 rounded-2xl p-5 flex items-start space-x-4 hover:border-primary/50 hover:bg-gray-800 transition-all group cursor-pointer relative ${isSelected ? 'border-primary/80 ring-2 ring-primary/50' : ''}`}>
            {isSelected && (
                <div className="absolute top-3 right-3 bg-primary text-white rounded-full p-1 shadow-lg">
                    <CheckboxIcon className="h-4 w-4 stroke-width-3" />
                </div>
            )}
            <div className={`p-3 bg-gray-700/50 rounded-lg group-hover:bg-primary/20 transition-colors`}>
                <Icon className={`h-6 w-6 ${color} group-hover:text-primary-light transition-colors`} />
            </div>
            <div>
                 <h3 className="font-bold text-white mb-1 pr-8">
                    <a href={resource.url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="hover:text-primary-light focus:outline-none focus:ring-1 focus:ring-primary/50 rounded transition-colors static-link">
                        {resource.title}
                    </a>
                </h3>
                <p className="text-sm text-gray-400">{resource.source}</p>
            </div>
        </div>
    );
};

export const ResearchLibraryView: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedResources, setSelectedResources] = useState<Set<number>>(new Set());
    const [isGenerating, setIsGenerating] = useState(false);
    const [summary, setSummary] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const filteredResources = MOCK_RESOURCES.filter(r => 
        r.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
        r.source.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const handleToggleResource = (resourceId: number) => {
        setSelectedResources(prev => {
            const newSet = new Set(prev);
            if (newSet.has(resourceId)) {
                newSet.delete(resourceId);
            } else {
                newSet.add(resourceId);
            }
            return newSet;
        });
    };

    const handleGenerateSummary = async () => {
        if (selectedResources.size === 0) return;
        
        setIsGenerating(true);
        setError(null);
        setSummary(null);

        try {
            const resourcesToSummarize = MOCK_RESOURCES.filter(r => selectedResources.has(r.id));
            const generatedSummary = await generateSummaryForResources(resourcesToSummarize);
            setSummary(generatedSummary);
        } catch (err) {
            setError('Failed to generate summary. Please check your API key and try again.');
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-6 rounded-2xl">
                <h2 className="text-2xl font-bold text-white mb-2">Research Library</h2>
                <p className="text-gray-400 mb-4">Select curated resources to study, then generate a cohesive summary to create your own study guide.</p>
                <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search for topics like 'distillation', 'reactors', etc..."
                    className="w-full p-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition text-white placeholder-gray-400"
                />
            </div>
            
            <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-4 rounded-2xl flex items-center justify-between sticky top-4 z-10">
                <p className="font-semibold text-white">
                    {selectedResources.size} resource{selectedResources.size !== 1 ? 's' : ''} selected
                </p>
                <button
                    onClick={handleGenerateSummary}
                    disabled={isGenerating || selectedResources.size === 0}
                    className="flex items-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors shadow-lg shadow-primary/20 hover:shadow-primary/30 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isGenerating ? (
                        <>
                            <SparklesIcon className="h-5 w-5 animate-pulse" />
                            <span>Generating...</span>
                        </>
                    ) : (
                        <>
                            <SparklesIcon className="h-5 w-5" />
                            <span>Generate PDF Summary</span>
                        </>
                    )}
                </button>
            </div>

            {error && (
                <div className="bg-red-500/20 border border-red-500/50 text-red-300 p-4 rounded-lg">
                    {error}
                </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredResources.map(resource => (
                    <ResourceCard 
                        key={resource.id} 
                        resource={resource} 
                        isSelected={selectedResources.has(resource.id)}
                        onSelect={() => handleToggleResource(resource.id)}
                    />
                ))}
            </div>
            
            {summary && (
                <SummaryModal summary={summary} onClose={() => setSummary(null)} />
            )}
        </div>
    );
};
