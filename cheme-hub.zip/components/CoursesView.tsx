import React, { useState } from 'react';
import type { Course } from '../types';
import { CourseFormModal } from './CourseFormModal';
import { PlusIcon, EditIcon, TrashIcon } from './Icons';

interface CoursesViewProps {
  courses: Course[];
  onAddCourse: (course: Omit<Course, 'id'>) => void;
  onUpdateCourse: (course: Course) => void;
  onDeleteCourse: (courseId: string) => void;
}

export const CoursesView: React.FC<CoursesViewProps> = ({ courses, onAddCourse, onUpdateCourse, onDeleteCourse }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);

  const handleOpenAddModal = () => {
    setEditingCourse(null);
    setIsModalOpen(true);
  };
  
  const handleOpenEditModal = (course: Course) => {
    setEditingCourse(course);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingCourse(null);
  };

  const handleSaveCourse = (courseData: Course | Omit<Course, 'id'>) => {
    if ('id' in courseData && courseData.id) {
      onUpdateCourse(courseData as Course);
    } else {
      onAddCourse(courseData);
    }
    handleCloseModal();
  };
  
  return (
    <>
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-white">Course Management</h2>
          <button
            onClick={handleOpenAddModal}
            className="flex items-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark transition-colors shadow-lg shadow-primary/20 hover:shadow-primary/30"
          >
            <PlusIcon className="h-5 w-5" />
            <span>Add New Course</span>
          </button>
        </div>
        <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 rounded-2xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
                {courses.map(course => (
                    <div key={course.id} className="bg-gray-900/50 p-4 rounded-xl border border-gray-700/50 flex flex-col justify-between hover:border-primary/50 transition-colors">
                        <div>
                            <h3 className="font-bold text-lg text-white">{course.title}</h3>
                            <p className="text-sm text-gray-400 capitalize">{course.difficulty_level}</p>
                            <p className="text-xs text-gray-500 mt-2">{course.modules.length} modules • {course.assignments?.length || 0} assignments</p>
                        </div>
                        <div className="flex items-center justify-end space-x-2 mt-4">
                            <button onClick={() => handleOpenEditModal(course)} className="p-2 text-gray-400 hover:text-primary-light rounded-full hover:bg-primary/10 transition-colors" aria-label={`Edit ${course.title}`}><EditIcon className="h-5 w-5" /></button>
                            <button onClick={() => onDeleteCourse(course.id)} className="p-2 text-gray-400 hover:text-accent-red rounded-full hover:bg-red-500/10 transition-colors" aria-label={`Delete ${course.title}`}><TrashIcon className="h-5 w-5" /></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
      <CourseFormModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onSave={handleSaveCourse}
        course={editingCourse}
      />
    </>
  );
};