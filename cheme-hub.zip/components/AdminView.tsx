
import React from 'react';
import { MOCK_USERS } from '../constants';
import type { User, Course } from '../types';
import { ServerIcon, ShieldIcon, SparklesIcon } from './Icons';
import { CoursesView } from './CoursesView';

const StatusCard: React.FC<{
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
    label: string;
    status: 'Operational' | 'Degraded' | 'Offline';
}> = ({ icon: Icon, label, status }) => {
    const statusColors = {
        Operational: 'bg-green-400',
        Degraded: 'bg-yellow-400',
        Offline: 'bg-red-500',
    };
    return (
        <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-4 rounded-xl flex items-center justify-between">
            <div className="flex items-center space-x-3">
                <Icon className="h-6 w-6 text-gray-400" />
                <span className="font-semibold text-white">{label}</span>
            </div>
            <div className="flex items-center space-x-2">
                <div className={`h-2.5 w-2.5 rounded-full ${statusColors[status]}`}></div>
                <span className="text-sm text-gray-300">{status}</span>
            </div>
        </div>
    );
};

const UserTableRow: React.FC<{ user: User }> = ({ user }) => {
  const getRoleStyles = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-accent-red/20 text-accent-red';
      case 'instructor': return 'bg-accent-blue/20 text-accent-blue';
      default: return 'bg-green-500/20 text-green-400';
    }
  };

  return (
    <tr className="border-b border-gray-700/50 hover:bg-gray-800/40">
        <td className="p-4">
            <div className="flex items-center space-x-3">
                 <div className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center text-white font-bold">
                    {user.name.charAt(0)}
                </div>
                <div>
                    <p className="font-semibold text-white">{user.name}</p>
                    <p className="text-sm text-gray-400">{user.email}</p>
                </div>
            </div>
        </td>
        <td className="p-4">
            <span className={`text-xs px-2 py-1 rounded-full inline-block font-medium capitalize ${getRoleStyles(user.role)}`}>
                {user.role}
            </span>
        </td>
        <td className="p-4">
            <span className="text-xs px-2 py-1 rounded-full inline-block font-medium bg-green-500/20 text-green-400">
                Active
            </span>
        </td>
        <td className="p-4">
            <div className="flex items-center space-x-2">
                <button className="px-3 py-1 text-xs font-semibold rounded-md bg-gray-700 hover:bg-gray-600 text-white transition-colors">Edit</button>
                <button className="px-3 py-1 text-xs font-semibold rounded-md bg-accent-red/80 hover:bg-accent-red text-white transition-colors">Delete</button>
            </div>
        </td>
    </tr>
  );
};

interface AdminViewProps {
  courses: Course[];
  onAddCourse: (course: Omit<Course, 'id'>) => void;
  onUpdateCourse: (course: Course) => void;
  onDeleteCourse: (courseId: string) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ courses, onAddCourse, onUpdateCourse, onDeleteCourse }) => {
    const users = Object.values(MOCK_USERS);
    
    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-white tracking-tight">Admin Panel</h1>
            
            {/* System Status Section */}
            <div>
                <h2 className="text-xl font-semibold text-white mb-4">System Status</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <StatusCard icon={ServerIcon} label="API Status" status="Operational" />
                    <StatusCard icon={ShieldIcon} label="Database" status="Operational" />
                    <StatusCard icon={SparklesIcon} label="AI Service" status="Operational" />
                </div>
            </div>
            
            {/* Course Management Section */}
            <CoursesView
                courses={courses}
                onAddCourse={onAddCourse}
                onUpdateCourse={onUpdateCourse}
                onDeleteCourse={onDeleteCourse}
            />

            {/* User Management Section */}
            <div>
                <h2 className="text-xl font-semibold text-white mb-4">User Management</h2>
                <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 rounded-2xl overflow-hidden">
                    <table className="w-full text-sm text-left text-gray-300">
                        <thead className="bg-gray-900/50 text-xs text-gray-400 uppercase tracking-wider">
                            <tr>
                                <th scope="col" className="p-4">User</th>
                                <th scope="col" className="p-4">Role</th>
                                <th scope="col" className="p-4">Status</th>
                                <th scope="col" className="p-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {users.map(user => <UserTableRow key={user.id} user={user} />)}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};