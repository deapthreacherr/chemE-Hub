import React, { useState } from 'react';
import type { Message } from '../types';
import { ChatWindow } from './ChatWindow';

interface PersonalizedLearningViewProps {
  messages: Message[];
  isLoading: boolean;
  onSendMessage: (content: string, learningLevel: string) => void;
}

export const PersonalizedLearningView: React.FC<PersonalizedLearningViewProps> = ({ messages, isLoading, onSendMessage }) => {
    const [learningLevel, setLearningLevel] = useState('Undergraduate - Year 3');

    const handleSendMessage = (content: string) => {
        onSendMessage(content, learningLevel);
    };

    return (
        <div className="space-y-8 h-full flex flex-col">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-6 rounded-2xl">
                    <h2 className="text-lg font-bold text-white mb-2">Adaptive Learning Paths</h2>
                    <p className="text-sm text-gray-400 mb-4">Select your current level of understanding to tailor the AI's responses to your needs.</p>
                    <select
                        value={learningLevel}
                        onChange={(e) => setLearningLevel(e.target.value)}
                        className="w-full p-3 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent transition text-white"
                    >
                        <option>High School</option>
                        <option>Undergraduate - Year 1</option>
                        <option>Undergraduate - Year 2</option>
                        <option>Undergraduate - Year 3</option>
                        <option>Undergraduate - Year 4</option>
                        <option>Graduate Level</option>
                        <option>Professional Refresher</option>
                    </select>
                </div>
                 <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-6 rounded-2xl">
                    <h2 className="text-lg font-bold text-white mb-2">Collaborative Learning</h2>
                    <p className="text-sm text-gray-400 mb-4">Connect with peers, form study groups, and solve problems together.</p>
                    <button disabled className="w-full px-4 py-2 bg-primary/50 text-white/50 rounded-lg cursor-not-allowed">
                        Coming Soon
                    </button>
                </div>
            </div>
            <div className="flex-1 min-h-0">
                <ChatWindow
                    messages={messages}
                    isLoading={isLoading}
                    onSendMessage={handleSendMessage}
                />
            </div>
        </div>
    );
};
