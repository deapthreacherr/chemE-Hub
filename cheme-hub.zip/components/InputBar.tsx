import React from 'react';
import { SendIcon } from './Icons';

interface InputBarProps {
  inputValue: string;
  setInputValue: (value: string) => void;
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

export const InputBar: React.FC<InputBarProps> = ({ inputValue, setInputValue, onSendMessage, isLoading }) => {
  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if (!isLoading && inputValue.trim()) {
      onSendMessage(inputValue);
      setInputValue('');
    }
  };

  return (
    <div className="border-t border-gray-700/50 p-4 bg-gray-800/50 rounded-b-2xl">
      <div className="relative">
        <textarea
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyPress}
          placeholder="Ask me anything..."
          className="w-full p-3 pr-28 bg-gray-700/50 border border-gray-600/50 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none transition text-white placeholder-gray-400"
          rows={2}
          disabled={isLoading}
        />
        <div className="absolute top-1/2 right-3 transform -translate-y-1/2 flex items-center space-x-2">
            <button
                onClick={handleSend}
                disabled={isLoading || !inputValue.trim()}
                className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-dark disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 transition-all duration-200 shadow-lg shadow-primary/20 hover:shadow-primary/30"
            >
                <SendIcon className="h-4 w-4" />
                <span className="text-sm font-semibold">Send</span>
            </button>
        </div>
      </div>
    </div>
  );
};
