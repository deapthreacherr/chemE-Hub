import React, { useState } from 'react';

interface TooltipData {
    x: number;
    y: number;
    title: string;
    description: string;
}

const componentInfo: Record<string, { title: string; description: string }> = {
    condenser: {
        title: 'Condenser',
        description: 'Cools the hot vapor leaving the top of the column, condensing it back into a liquid. Part of this liquid is returned to the column as reflux, and the rest is drawn off as the distillate product.'
    },
    reboiler: {
        title: 'Reboiler',
        description: 'A heat exchanger that heats the liquid from the bottom of the column to create vapor. This vapor is sent back into the column to drive the separation process.'
    },
    trays: {
        title: 'Sieve Trays',
        description: 'Plates that force the rising vapor to bubble through the descending liquid. This intimate contact allows for mass transfer, separating components based on their boiling points at each stage.'
    },
    feed: {
        title: 'Feed Inlet',
        description: 'The point where the initial mixture to be separated is introduced into the column. The feed tray location is optimized based on the mixture\'s composition and temperature.'
    },
    distillate: {
        title: 'Distillate Outlet',
        description: 'Where the more volatile component (lower boiling point) is removed from the system as a vapor or liquid product after being condensed.'
    },
    bottoms: {
        title: 'Bottoms Outlet',
        description: 'Where the less volatile component (higher boiling point) is removed from the bottom of the column as a liquid product.'
    }
};

const Tooltip: React.FC<{ tooltip: TooltipData; onClose: () => void }> = ({ tooltip, onClose }) => (
    <div 
        className="absolute bg-gray-900/80 backdrop-blur-md border border-gray-700/50 rounded-lg shadow-2xl p-4 w-64 text-sm z-10 animate-fade-in"
        style={{ top: tooltip.y, left: tooltip.x }}
    >
        <div className="flex justify-between items-center mb-2">
            <h4 className="font-bold text-primary-light">{tooltip.title}</h4>
            <button onClick={onClose} className="text-gray-500 hover:text-white">&times;</button>
        </div>
        <p className="text-gray-300">{tooltip.description}</p>
    </div>
);


export const VisualizationDemoView: React.FC = () => {
    const [activeTooltip, setActiveTooltip] = useState<TooltipData | null>(null);

    const handleComponentClick = (e: React.MouseEvent<SVGElement>, componentKey: string) => {
        e.stopPropagation();
        
        if (activeTooltip && activeTooltip.title === componentInfo[componentKey].title) {
            setActiveTooltip(null);
            return;
        }

        const container = e.currentTarget.closest<HTMLElement>('.relative');
        if (!container) return;

        const containerRect = container.getBoundingClientRect();
        
        const clickX = e.clientX - containerRect.left;
        const clickY = e.clientY - containerRect.top;

        const TOOLTIP_WIDTH = 256; // Corresponds to Tailwind's w-64
        const TOOLTIP_HEIGHT_ESTIMATE = 180; // An estimated height, adjust if necessary
        const PADDING = 16; // Space from container edges
        const CURSOR_OFFSET = 20; // Space from the cursor

        // --- Calculate X position ---
        let newX = clickX + CURSOR_OFFSET;

        // Check right boundary: if tooltip overflows, place it left of the cursor
        if (newX + TOOLTIP_WIDTH + PADDING > containerRect.width) {
            newX = clickX - TOOLTIP_WIDTH - CURSOR_OFFSET;
        }
        // Check left boundary: if it still overflows, clamp it to the edge
        if (newX < PADDING) {
            newX = PADDING;
        }

        // --- Calculate Y position ---
        let newY = clickY + CURSOR_OFFSET;

        // Check bottom boundary: if tooltip overflows, place it above the cursor
        if (newY + TOOLTIP_HEIGHT_ESTIMATE + PADDING > containerRect.height) {
            newY = clickY - TOOLTIP_HEIGHT_ESTIMATE - CURSOR_OFFSET;
        }
        // Check top boundary: if it still overflows, clamp it to the edge
        if (newY < PADDING) {
            newY = PADDING;
        }

        setActiveTooltip({
            x: newX,
            y: newY,
            title: componentInfo[componentKey].title,
            description: componentInfo[componentKey].description,
        });
    };

    const handleCloseTooltip = () => {
        setActiveTooltip(null);
    }
    
    return (
        <div className="space-y-6">
            <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-6 rounded-2xl">
                <h2 className="text-2xl font-bold text-white mb-2">Process Visualization</h2>
                <p className="text-gray-400">Interactive diagrams of key chemical engineering processes. Click on the highlighted components of the fractional distillation column below to learn more about their function.</p>
            </div>
            <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 p-8 rounded-2xl flex items-center justify-center relative" onClick={handleCloseTooltip}>
                {activeTooltip && <Tooltip tooltip={activeTooltip} onClose={handleCloseTooltip} />}
                
                <svg width="80%" viewBox="0 0 400 600" xmlns="http://www.w3.org/2000/svg" className="max-w-md">
                    <defs>
                        <linearGradient id="towerGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" style={{stopColor: '#4A5568'}} />
                            <stop offset="50%" style={{stopColor: '#718096'}} />
                            <stop offset="100%" style={{stopColor: '#4A5568'}} />
                        </linearGradient>
                        <style>
                            {`.label { font-family: 'Inter', sans-serif; font-size: 12px; fill: #E2E8F0; user-select: none; }`}
                            {`.label-line { stroke: #A0AEC0; stroke-width: 1.5; stroke-dasharray: 4 2; }`}
                            {`.arrow-head { fill: #A0AEC0; }`}
                            {`.flow-arrow { stroke: #DD6B20; stroke-width: 2.5; }`}
                            {`.flow-head { fill: #DD6B20; }`}
                            
                            {`.interactive {
                                cursor: pointer;
                                transition: transform 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                                transform-box: fill-box;
                                transform-origin: center;
                            }`}
                            {`.interactive rect, .interactive line, .interactive path, .interactive polygon {
                                transition: stroke 0.2s ease, fill 0.2s ease, stroke-width 0.2s ease;
                            }`}
                            {`.interactive:hover {
                                transform: scale(1.04);
                            }`}
                            {`.interactive:hover rect,
                              .interactive:hover line,
                              .interactive:hover path {
                                stroke: #ED8936;
                                stroke-width: 2.5;
                            }`}
                            {`.interactive:hover polygon {
                                fill: #ED8936;
                            }`}
                        </style>
                    </defs>
                    
                    {/* Main Tower */}
                    <rect x="150" y="100" width="100" height="400" fill="url(#towerGradient)" stroke="#2D3748" strokeWidth="2" rx="5"/>

                    {/* Trays */}
                    <g className="interactive" onClick={(e) => handleComponentClick(e, 'trays')}>
                        <title>Click to learn about Sieve Trays</title>
                        {[...Array(8)].map((_, i) => (
                            <line key={i} x1="155" y1={140 + i * 40} x2="245" y2={140 + i * 40} stroke="#2D3748" strokeWidth="2"/>
                        ))}
                    </g>

                    {/* Feed Inlet */}
                    <g className="interactive" onClick={(e) => handleComponentClick(e, 'feed')}>
                        <title>Click to learn about the Feed Inlet</title>
                        <path d="M 50 300 L 150 300" className="flow-arrow" />
                        <polygon points="145,295 155,300 145,305" className="flow-head" />
                        <text x="45" y="295" className="label" textAnchor="end">Feed</text>
                    </g>

                    {/* Condenser */}
                    <g className="interactive" onClick={(e) => handleComponentClick(e, 'condenser')}>
                        <title>Click to learn about the Condenser</title>
                        <rect x="125" y="50" width="150" height="40" fill="#4299E1" stroke="#2D3748" strokeWidth="2" rx="5"/>
                        <path d="M 200 90 L 200 100" stroke="#718096" strokeWidth="2"/>
                        <text x="280" y="75" className="label" textAnchor="middle">Condenser</text>
                    </g>
                    
                    {/* Distillate Outlet */}
                    <g className="interactive" onClick={(e) => handleComponentClick(e, 'distillate')}>
                        <title>Click to learn about the Distillate Outlet</title>
                        <path d="M 275 70 L 350 70" className="flow-arrow" />
                        <polygon points="345,65 355,70 345,75" className="flow-head" />
                        <text x="360" y="65" className="label">Distillate</text>
                        <text x="360" y="80" className="label">(Vapors)</text>
                    </g>

                    {/* Reboiler */}
                    <g className="interactive" onClick={(e) => handleComponentClick(e, 'reboiler')}>
                       <title>Click to learn about the Reboiler</title>
                        <rect x="125" y="510" width="150" height="40" fill="#F56565" stroke="#2D3748" strokeWidth="2" rx="5"/>
                        <path d="M 200 500 L 200 510" stroke="#718096" strokeWidth="2"/>
                        <text x="200" y="575" className="label" textAnchor="middle">Reboiler</text>
                    </g>

                    {/* Bottoms Outlet */}
                    <g className="interactive" onClick={(e) => handleComponentClick(e, 'bottoms')}>
                        <title>Click to learn about the Bottoms Outlet</title>
                        <path d="M 200 550 L 200 590 L 300 590" className="flow-arrow" strokeLinecap="round" />
                        <polygon points="295,585 305,590 295,595" className="flow-head" />
                        <text x="310" y="585" className="label">Bottoms</text>
                        <text x="310" y="600" className="label">(Liquid)</text>
                    </g>

                    {/* Static Labels */}
                    <line x1="250" y1="140" x2="300" y2="100" className="label-line" />
                    <polygon points="296,96 304,98 302,104" className="arrow-head" />
                    <text x="305" y="95" className="label">Trays</text>

                    <line x1="150" y1="420" x2="100" y2="460" className="label-line" />
                    <polygon points="104,464 96,462 98,456" className="arrow-head" />
                    <text x="95" y="475" className="label" textAnchor="end">Stripping</text>
                    <text x="95" y="490" className="label" textAnchor="end">Section</text>

                     <line x1="250" y1="220" x2="300" y2="180" className="label-line" />
                    <polygon points="296,176 304,178 302,184" className="arrow-head" />
                    <text x="305" y="175" className="label">Rectifying</text>
                     <text x="305" y="190" className="label">Section</text>
                </svg>
            </div>
        </div>
    );
};