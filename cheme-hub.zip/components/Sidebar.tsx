

import React from 'react';
import type { NavItem, Course, User, Module } from '../types';
import { UserRole } from '../types';
import { ChemIcon, CheckboxIcon, DotIcon } from './Icons';

interface SidebarProps {
  navItems: NavItem[];
  activeNav: string;
  setActiveNav: (name: string) => void;
  courses: Course[];
  selectedCourse: Course | null;
  setSelectedCourse: (course: Course | null) => void;
  currentUser: User;
  onToggleModule: (courseId: string, moduleId: string) => void;
}

const CourseModule: React.FC<{
    module: Module;
    isCompleted: boolean;
    onToggle: () => void;
}> = ({ module, isCompleted, onToggle }) => (
    <div 
      onClick={onToggle}
      className="flex items-center space-x-3 pl-8 pr-4 py-2 rounded-lg cursor-pointer hover:bg-gray-800/50 group"
    >
      <CheckboxIcon className={`h-5 w-5 flex-shrink-0 transition-colors ${
        isCompleted ? 'text-primary' : 'text-gray-600 group-hover:text-gray-400'
      }`} />
      <span className={`text-sm font-medium transition-colors ${
        isCompleted ? 'text-gray-300' : 'text-gray-500 group-hover:text-gray-300'
      }`}>{module.title}</span>
    </div>
);


export const Sidebar: React.FC<SidebarProps> = ({ navItems, activeNav, setActiveNav, courses, selectedCourse, setSelectedCourse, currentUser, onToggleModule }) => {
  const getActiveNavStyle = (itemName: string) => {
    const baseStyle = 'text-white shadow-lg';
    if (itemName === 'Admin') return `bg-accent-red ${baseStyle}`;
    return `bg-primary ${baseStyle}`;
  };

  const getRoleIndicator = (item: NavItem) => {
      if (item.name === 'Admin') return <DotIcon className="h-4 w-4 text-accent-red" />;
      return null;
  }

  return (
    <aside className="w-72 bg-gray-900/70 backdrop-blur-lg p-6 flex flex-col border-r border-gray-800/50">
      <div className="flex items-center space-x-3 mb-10">
        <ChemIcon className="h-8 w-8 text-primary" />
        <h1 className="text-2xl font-bold text-white tracking-tight">ChemE Hub</h1>
      </div>
      
      <nav className="flex-1">
        <div className="space-y-2">
            {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeNav === item.name;
            return (
                <a
                key={item.name}
                href="#"
                onClick={(e) => {
                    e.preventDefault();
                    setActiveNav(item.name);
                }}
                className={`flex items-center justify-between px-4 py-3 rounded-lg transition-all duration-200 font-semibold ${
                    isActive 
                    ? getActiveNavStyle(item.name)
                    : 'text-gray-400 hover:bg-gray-800/50 hover:text-white'
                }`}
                >
                <div className="flex items-center space-x-3">
                  <Icon className="h-5 w-5" />
                  <span>{item.name}</span>
                </div>
                {item.permissions && getRoleIndicator(item)}
                </a>
            );
            })}
        </div>

        <div className="mt-8">
            <h2 className="px-4 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
                Course Context
            </h2>
            <div className="space-y-1">
                <div
                    onClick={() => setSelectedCourse(null)}
                    className={`flex items-center space-x-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                        !selectedCourse
                        ? 'bg-gray-800 text-white'
                        : 'text-gray-400 hover:bg-gray-800/50 hover:text-white'
                    }`}
                >
                    <span>General AI Tutor</span>
                </div>
                {courses.map((course) => {
                    const isSelected = selectedCourse?.id === course.id;
                    const courseProgress = currentUser.progress?.[course.id] || [];
                    return (
                        <div key={course.id}>
                            <div
                                onClick={() => setSelectedCourse(course)}
                                className={`flex items-center justify-between space-x-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                                    isSelected
                                    ? 'bg-gray-800 text-white'
                                    : 'text-gray-400 hover:bg-gray-800/50 hover:text-white'
                                }`}
                            >
                                <span className="flex-1">{course.title}</span>
                                {currentUser.role === 'student' && (
                                  <span className="text-xs text-gray-500">{courseProgress.length}/{course.modules.length}</span>
                                )}
                            </div>
                            {isSelected && currentUser.role === 'student' && (
                                <div className="py-2 space-y-1">
                                    {course.modules.map(module => (
                                        <CourseModule
                                            key={module.id}
                                            module={module}
                                            isCompleted={courseProgress.includes(module.id)}
                                            onToggle={() => onToggleModule(course.id, module.id)}
                                        />
                                    ))}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
      </nav>

      {/* Footer / User Profile Placeholder */}
      <div className="mt-auto">
        <div className="bg-gray-800/50 p-4 rounded-lg">
           <p className="text-white font-semibold text-sm">AI-Powered Learning</p>
           <p className="text-gray-400 text-xs">Upgrade to Pro for unlimited access.</p>
        </div>
      </div>
    </aside>
  );
};