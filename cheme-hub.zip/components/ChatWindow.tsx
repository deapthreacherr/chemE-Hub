import React, { useState, useEffect, useRef } from 'react';
import type { Message } from '../types';
import { MessageBubble } from './MessageBubble';
import { InputBar } from './InputBar';
import { SparklesIcon } from './Icons';

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  onSendMessage: (content: string) => void;
}

export const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, onSendMessage }) => {
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);
  
  return (
    <div className="bg-gray-800/50 backdrop-blur-md border border-gray-700/50 rounded-2xl h-full flex flex-col">
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} onSuggestionClick={onSendMessage} />
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-700/50 px-4 py-3 rounded-lg animate-pulse">
              <div className="flex items-center space-x-2">
                <SparklesIcon className="h-5 w-5 text-primary-light" />
                <span className="text-sm text-gray-300">AI is thinking...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <InputBar
        inputValue={inputValue}
        setInputValue={setInputValue}
        onSendMessage={onSendMessage}
        isLoading={isLoading}
      />
    </div>
  );
};
