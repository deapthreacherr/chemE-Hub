

import type { Course, Stats, Message, NavItem, Recommendation, User } from './types';
import { MessageType, UserRole } from './types';
import { DashboardIcon, BookIcon, ChartIcon, SettingsIcon, ShieldIcon, SparklesIcon, EyeIcon, LibraryIcon } from './components/Icons';

export const MOCK_COURSES: Course[] = [
  { 
    id: 'che-317', 
    title: 'Separation Processes I', 
    difficulty_level: 'intermediate',
    modules: [
      { id: 'che-317-mod-1', title: 'Fundamentals of Distillation' },
      { id: 'che-317-mod-2', title: 'Column Design & Operation' },
      { id: 'che-317-mod-3', title: 'Liquid-Liquid Extraction' },
      { id: 'che-317-mod-4', title: 'Gas Absorption' },
    ],
    assignments: [],
  },
  { 
    id: 'che-512', 
    title: 'Technical Seminar', 
    difficulty_level: 'advanced',
    modules: [
      { id: 'che-512-mod-1', title: 'Literature Review Techniques' },
      { id: 'che-512-mod-2', title: 'Presentation Skills' },
      { id: 'che-512-mod-3', title: 'Technical Writing' },
    ],
    assignments: [],
  },
  { 
    id: 'che-513', 
    title: 'Process Dynamics & Control', 
    difficulty_level: 'advanced',
    modules: [
        { id: 'che-513-mod-1', title: 'Modeling Dynamic Systems' },
        { id: 'che-513-mod-2', title: 'Laplace Transforms' },
        { id: 'che-513-mod-3', title: 'Feedback Controllers (PID)' },
        { id: 'che-513-mod-4', title: 'System Stability Analysis' },
    ],
    assignments: [],
  },
  { 
    id: 'che-552', 
    title: 'Industrial Pollution Control', 
    difficulty_level: 'intermediate',
    modules: [
      { id: 'che-552-mod-1', title: 'Air Pollution Control' },
      { id: 'che-552-mod-2', title: 'Wastewater Treatment' },
      { id: 'che-552-mod-3', title: 'Solid Waste Management' },
    ],
    assignments: [],
  },
];

export const MOCK_STATS: Stats = {
  users: 1337,
  courses: MOCK_COURSES.length,
  sessions: 4200,
};

export const WELCOME_MESSAGE: Message = {
  id: 'welcome-1',
  type: MessageType.AI,
  content: "Welcome to ChemE Hub! I'm your AI tutor. Your personalized dashboard is ready. Select a course context from the sidebar and ask me a question to begin.",
  timestamp: new Date(),
  suggestions: [
    'Explain PID controllers',
    'Summarize the goal of wastewater treatment',
    'What are key technical writing principles?'
  ]
};

export const MOCK_USERS: Record<string, User> = {
  student: { 
    id: 'user-1', 
    name: 'Perry', 
    email: 'perry@chemehub.io',
    role: UserRole.STUDENT, 
    progress: {
        'che-513': ['che-513-mod-1', 'che-513-mod-2'],
        'che-317': ['che-317-mod-1', 'che-317-mod-2', 'che-317-mod-3', 'che-317-mod-4'],
    } 
  },
  instructor: { id: 'user-2', name: 'Dr. Levenspiel', email: 'levenspiel@chemehub.io', role: UserRole.INSTRUCTOR, progress: {} },
  admin: { id: 'user-3', name: 'Admin Eve', email: 'eve@chemehub.io', role: UserRole.ADMIN, progress: {} },
};

export const NAV_ITEMS: NavItem[] = [
    { name: 'Dashboard', icon: DashboardIcon },
    { name: 'Personalized Learning', icon: SparklesIcon },
    { name: 'Visualization Demo', icon: EyeIcon },
    { name: 'Research Library', icon: LibraryIcon },
    { name: 'Admin', icon: ShieldIcon, permissions: [UserRole.ADMIN] },
    { name: 'Settings', icon: SettingsIcon },
];

export const RECOMMENDATIONS_DATA: Recommendation[] = [
    { id: 'rec1', title: 'Review Feedback Controllers', category: 'Process Control', status: 'In Progress' },
    { id: 'rec2', title: 'Start Air Pollution Module', category: 'Pollution Control', status: 'Not Started' },
    { id: 'rec3', title: 'Complete Presentation Skills', category: 'Technical Seminar', status: 'Completed' },
];